/**
 * App.jsx - Componente raíz del módulo Registro
 * Esta aplicación demo simula el flujo básico:
 *  - Registrar entrada/salida de personal
 *  - Mostrar registros en una tabla
 *  - Confirmaciones mediante modal
 *
 * Buenas prácticas aplicadas:
 *  - Componentes pequeños y reutilizables
 *  - Hooks para manejo de estado y persistencia local
 *  - Comentarios y codificación clara
 */
import React, { useState } from 'react';
import Header from './components/Header.jsx';
import RegisterForm from './components/RegisterForm.jsx';
import RecordsTable from './components/RecordsTable.jsx';
import Modal from './components/Modal.jsx';
import { useLocalStorage } from './hooks/useLocalStorage.js';

const App = () => {
  // Registros guardados en localStorage para demo; en producción usar API.
  const [records, setRecords] = useLocalStorage('records', []);
  const [modal, setModal] = useState({ open:false, message:'' });

  // Añade un nuevo registro (entrada o salida)
  const addRecord = (record) => {
    // Validación mínima: id y type
    if (!record.identification || !record.type) {
      setModal({ open:true, message: 'Faltan datos obligatorios.' });
      return;
    }
    const newRecord = {
      id: Date.now(),
      ...record
    };
    setRecords([newRecord, ...records]);
    setModal({ open:true, message: 'Registro almacenado correctamente.' });
  };

  // Elimina un registro por id (con confirmación)
  const removeRecord = (id) => {
    if (!confirm('¿Eliminar este registro?')) return;
    const filtered = records.filter(r => r.id !== id);
    setRecords(filtered);
  };

  return (
    <div className="app-container">
      <Header title="Control de Ingreso y Salida" />
      <main>
        <section className="form-section">
          <RegisterForm onSave={addRecord} />
        </section>
        <section className="table-section">
          <RecordsTable records={records} onDelete={removeRecord} />
        </section>
      </main>

      <Modal open={modal.open} onClose={() => setModal({ open:false, message:'' })}>
        <p>{modal.message}</p>
      </Modal>
    </div>
  );
};

export default App;
