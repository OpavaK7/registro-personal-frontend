// Header.jsx - componente de presentación (Navbar simple)
import React from 'react';

const Header = ({ title }) => {
  return (
    <header className="header">
      <h1>{title}</h1>
      <nav>
        <ul className="nav-list">
          <li>Inicio</li>
          <li>Registro</li>
          <li>Reportes</li>
          <li>Configuración</li>
        </ul>
      </nav>
    </header>
  );
};

export default Header;
