// RegisterForm.jsx - formulario controlado para registrar entrada/salida
import React, { useState } from 'react';

const initialForm = {
  identification: '',
  name: '',
  type: 'entrada', // 'entrada' o 'salida'
  observation: ''
};

const RegisterForm = ({ onSave }) => {
  const [form, setForm] = useState(initialForm);

  // Maneja cambios en inputs de manera controlada
  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
  };

  // Envía el formulario y limpia campos
  const handleSubmit = (e) => {
    e.preventDefault();
    // Se envía sólo lo necesario
    onSave({
      identification: form.identification.trim(),
      name: form.name.trim(),
      type: form.type,
      observation: form.observation.trim(),
      timestamp: new Date().toISOString()
    });
    setForm(initialForm);
  };

  return (
    <form className="register-form" onSubmit={handleSubmit}>
      <label>
        Identificación
        <input
          name="identification"
          value={form.identification}
          onChange={handleChange}
          placeholder="Documento o código"
          required
        />
      </label>

      <label>
        Nombre
        <input
          name="name"
          value={form.name}
          onChange={handleChange}
          placeholder="Nombre completo"
        />
      </label>

      <label>
        Tipo
        <select name="type" value={form.type} onChange={handleChange}>
          <option value="entrada">Entrada</option>
          <option value="salida">Salida</option>
        </select>
      </label>

      <label>
        Observación
        <input
          name="observation"
          value={form.observation}
          onChange={handleChange}
          placeholder="Observaciones (opcional)"
        />
      </label>

      <div className="form-actions">
        <button type="submit">Guardar</button>
        <button type="button" onClick={() => setForm(initialForm)}>Limpiar</button>
      </div>
    </form>
  );
};

export default RegisterForm;
