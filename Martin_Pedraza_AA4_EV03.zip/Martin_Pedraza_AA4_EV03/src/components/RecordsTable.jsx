// RecordsTable.jsx - despliega registros en una tabla sencilla
import React from 'react';

const RecordsTable = ({ records, onDelete }) => {
  return (
    <div className="records-table">
      {records.length === 0 ? (
        <p>No hay registros aún.</p>
      ) : (
        <table>
          <thead>
            <tr>
              <th>Identificación</th>
              <th>Nombre</th>
              <th>Tipo</th>
              <th>Hora</th>
              <th>Observación</th>
              <th>Acciones</th>
            </tr>
          </thead>
          <tbody>
            {records.map(r => (
              <tr key={r.id}>
                <td>{r.identification}</td>
                <td>{r.name}</td>
                <td>{r.type}</td>
                <td>{new Date(r.timestamp).toLocaleString()}</td>
                <td>{r.observation}</td>
                <td>
                  <button onClick={() => onDelete(r.id)} aria-label={"Eliminar registro " + r.id}>
                    Eliminar
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default RecordsTable;
