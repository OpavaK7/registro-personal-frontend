// Modal.jsx - ventana emergente simple
import React from 'react';

const Modal = ({ open, onClose, children }) => {
  if (!open) return null;
  return (
    <div className="modal-backdrop" role="dialog" aria-modal="true">
      <div className="modal-content">
        <button className="modal-close" onClick={onClose} aria-label="Cerrar">x</button>
        <div className="modal-body">{children}</div>
      </div>
    </div>
  );
};

export default Modal;
