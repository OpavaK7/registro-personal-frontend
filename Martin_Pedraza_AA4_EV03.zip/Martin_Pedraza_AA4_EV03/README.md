# Módulo Frontend - Registro de Ingreso/Salida

**Nombre del aprendiz:** Martin Pedraza 
**Evidencia:** AA4_EV03  
**Proyecto:** Software de registro de ingreso y salida de personal (Frontend - React)

## Contenido de la carpeta
- `package.json` (config mínima para referencia)
- `src/`:
  - `index.html` (archivo estático de ejemplo)
  - `index.jsx` (punto de entrada)
  - `App.jsx` (componente raíz)
  - `components/`
    - `Header.jsx`
    - `RegisterForm.jsx`
    - `RecordsTable.jsx`
    - `Modal.jsx`
  - `hooks/`
    - `useLocalStorage.js`
  - `styles.css`
- `README.md` (este archivo)
- `git_instructions.txt` (cómo versionar el proyecto)

> Link Git Hub: https://github.com/OpavaK7/registro-personal-frontend.git